from sshpackagemanager import SSHPackageManager

hostname = "192.168.0.30"
username = "deb"
password = "deb"

# création de l'objet du type SSHPackageManager
package_manager = SSHPackageManager(hostname, username, password)


# Fonction pour afficher le menu et sélectionner les options
def main_menu():
    while True:
        print("\nMenu de gestion des paquets")
        print("1. Installer des paquets web (Apache, MariaDB et PHP)")
        print("2. Désinstaller des paquets web")
        print("3. Mettre à jour un paquet")
        print("4. Vérifier un paquet")
        print("5. Quitter")

        choice = input("Sélectionnez une option : ")

        if choice == "1":
            package_manager.install_packages("apache2 mariadb-server php php-mysql libapache2-mod-php")
        elif choice == "2":
            package_manager.remove_packages("apache2 mariadb-server php php-mysql libapache2-mod-php")
        elif choice == "3":
            package_name = input("Entrez le nom du paquet à mettre à jour : ")
            package_manager.update_package(package_name)
        elif choice == "4":
            package_name = input("Entrez le nom du paquet à vérifier : ")
            package_manager.verify_package(package_name)
        elif choice == "5":
            print("Fermeture du programme.")
            break
        else:
            print("Choix invalide, veuillez réessayer.")

    # Fermeture de la connexion SSH à la fin
    package_manager.close_connection()


# Lancer le menu principal
if __name__ == "__main__":
    main_menu()
