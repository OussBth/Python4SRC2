import paramiko


class SSHPackageManager:
    def __init__(self, hostname, username, password):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(hostname, username=username, password=password)

    def execute_command(self, command):
        command = f"export DEBIAN_FRONTEND=noninteractive && {command}"
        stdin, stdout, stderr = self.client.exec_command(command)
        return stdout.read().decode(), stderr.read().decode()

    def install_single_package(self, package):
        print(f"Installation du paquet {package}...")
        output, error = self.execute_command(f"sudo apt-get install -y {package}")
        if error:
            print(f"Erreur lors de l'installation de {package}: {error}")
        else:
            print(output)

    def install_packages(self, package_name, packages=None):
        packages = package_name.split(" ")
        for package in packages:
            output, error = self.execute_command(f"sudo apt-get update")
            if error:
                print(f"Erreur lors de la mise à jour des paquets : {error}")
            else:
                print(output)
                self.install_single_package(package)

    def verify_package(self, package_name):
        print(f"Vérification de l'installation de {package_name} avec dpkg...")
        output, error = self.execute_command(f"dpkg -l | grep {package_name}")
        if output:
            print(f"Le paquet {package_name} est installé.")
            return True
        else:
            print(f"Le paquet {package_name} n'est pas installé.")
            return False

    def update_package(self, package_name):
        if self.verify_package(package_name):
            print(f"Mise à jour du paquet {package_name}...")
            output, error = self.execute_command(
                f"sudo apt-get update && sudo apt-get install --only-upgrade -y {package_name}")
            if error:
                print(f"Erreur lors de la mise à jour de {package_name}: {error}")
            else:
                print(output)
        else:
            print(f"Le paquet {package_name} n'est pas installé, aucune mise à jour nécessaire.")

    def remove_package(self, package_name):
        print(f"Suppression du paquet {package_name}...")
        output, error = self.execute_command(f"sudo apt-get remove -y {package_name}")
        if error:
            print(f"Erreur lors de la suppression de {package_name}: {error}")
        else:
            print(output)
            print("Suppression des dépendances inutilisées...")
            autoremove_output, autoremove_error = self.execute_command("sudo apt-get autoremove -y")
            if autoremove_error:
                print(f"Erreur lors de l'autoremove : {autoremove_error}")
            else:
                print(autoremove_output)

    def remove_packages(self, package_name, packages=None):
        packages = package_name.split(" ")
        for package in packages:
            self.remove_package(package)

    def close_connection(self):
        self.client.close()
        print("Connexion SSH fermée.")
